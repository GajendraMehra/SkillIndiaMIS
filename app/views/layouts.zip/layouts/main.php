<?php

/* @var $this \yii\web\View */
/* @var $content string */
use yii\helpers\Url;
use aryelds\sweetalert\SweetAlert;

use backend\assets\AppAsset;
use backend\assets\DashboardAsset;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use backend\models\Notification;
use yii\widgets\Breadcrumbs;
// use yii\widgets\NotificationsWidget;
use common\widgets\Alert;
use machour\yii2\notifications\widgets\NotificationsWidget;
// echo Alert::widget();


DashboardAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <style>

        .normaliseBtn{
            border:0;
            background:transparent;
            cursor:pointer;
        }
        .fullwidth{
            width:86% !important;
        }
    </style>
    <script
  src="https://code.jquery.com/jquery-3.5.1.js"
  integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="
  crossorigin="anonymous"></script>
  <link href="vendor/select2/dist/css/select2.min.css" rel="stylesheet" />
  <!-- <script src="https://rawgit.com/select2/select2/master/dist/js/select2.js"></script> -->
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<?php $this->beginBody();
  if (Yii::$app->user->isGuest) {
    echo $content;
}else{?>

<div class="">

<!-- Left Panel -->
<?= $this->render('/layouts/flashes');

     NotificationsWidget::widget([
        'theme' => NotificationsWidget::THEME_TOASTR,
        'clientOptions' => [
            'location' => 'br',
        ],
        'counters' => [
            '.notifications-header-count',
            '.notifications-icon-count'
        ],
        'markAllSeenSelector' => '#notification-seen-all',
        'listSelector' => '#notifications',
    ]);
     Notification::notify(Notification::KEY_NEW_MESSAGE, 2, 10);
    
?>

<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="custom/images/logo1.png" height="80px" alt=""></a>
                <a class="navbar-brand hidden" href="./"><img src="custom/images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
            <?php 
            // render the menus according to the user role 
                switch (Yii::$app->user->identity->role) {
                    case '1':
                        echo $this->render('menu/admin.php');      
                    break;
                    case '2':
                        echo $this->render('menu/trainingPartner.php');      
                    break;
                    case '3':
                        echo $this->render('menu/trainingCenter.php');      
                    break;
                    case '4':
                        echo $this->render('menu/student.php');      
                    break;
                    
                    default:
                       
                    break;
                }
            ?>
                
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>

       <!-- Right Panel -->
<div id="right-panel" class="right-panel fullwidth" style="width:100%">

<!-- Header-->
<header id="header" class="header">

    <div class="header-menu">

        <div class="col-sm-7">
            <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
            <div class="header-left">
                <button class="search-trigger"><i class="fa fa-search"></i></button>
                <div class="form-inline">
                    <form class="search-form">
                        <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                        <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                    </form>
                </div>

                <div class="dropdown for-notification">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-bell"></i>
                        <span class="count bg-danger notifications-header-count">0</span>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="notification">
                        <p class="red">You have <span class="notifications-header-count">0</span> Notification</p>
                       <!-- <a class="dropdown-item media bg-flat-color-1" href="#">
                        <i class="fa fa-check"></i> -->
                <div id="notifications"></div>

                        <!-- <p>Server #1 overloaded.</p> -->
                    </a>
                        <!--  <a class="dropdown-item media bg-flat-color-4" href="#">
                        <i class="fa fa-info"></i>
                        <p>Server #2 overloaded.</p>
                    </a>
                        <a class="dropdown-item media bg-flat-color-5" href="#">
                        <i class="fa fa-warning"></i>
                        <p>Server #3 overloaded.</p>
                    </a> -->
                    </div>
                </div>

                <div class="dropdown for-message">
                    <button class="btn btn-secondary dropdown-toggle" type="button"
                        id="message"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="ti-email"></i>
                        <span class="count bg-primary">9</span>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="message">
                        <p class="red">You have 4 Mails</p>
                        <a class="dropdown-item media bg-flat-color-1" href="#">
                        <span class="photo media-left"><img alt="avatar" src="custom/images/avatar/1.jpg"></span>
                        <!-- <span class="message media-body">
                            <span class="name float-left">Jonathan Smith</span>
                            <span class="time float-right">Just now</span>
                                <p>Hello, this is an example msg</p>
                        </span> -->
                    </a>
                        <!-- <a class="dropdown-item media bg-flat-color-4" href="#">
                        <span class="photo media-left"><img alt="avatar" src="custom/images/avatar/2.jpg"></span>
                        <span class="message media-body">
                            <span class="name float-left">Jack Sanders</span>
                            <span class="time float-right">5 minutes ago</span>
                                <p>Lorem ipsum dolor sit amet, consectetur</p>
                        </span>
                    </a> -->
                        <!-- <a class="dropdown-item media bg-flat-color-5" href="#">
                        <span class="photo media-left"><img alt="avatar" src="custom/images/avatar/3.jpg"></span>
                        <span class="message media-body">
                            <span class="name float-left">Cheryl Wheeler</span>
                            <span class="time float-right">10 minutes ago</span>
                                <p>Hello, this is an example msg</p>
                        </span>
                    </a>
                        <a class="dropdown-item media bg-flat-color-3" href="#">
                        <span class="photo media-left"><img alt="avatar" src="custom/images/avatar/4.jpg"></span>
                        <span class="message media-body">
                            <span class="name float-left">Rachel Santos</span>
                            <span class="time float-right">15 minutes ago</span>
                                <p>Lorem ipsum dolor sit amet, consectetur</p>
                        </span>
                    </a> -->
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-5">
     
            <div class="user-area dropdown float-right">
            <h5 class="float-left mr-3"><?= Yii::$app->user->identity->username; ?>  <span class="badge badge-pill badge-success"><?= Yii::$app->params['role_'.Yii::$app->user->identity->role] ?></span></h5>
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle" src="custom/images/admin.jpg" alt="User Avatar">
                </a>
                <div class="user-menu dropdown-menu">
                    <a class="nav-link" href="#"><i class="fa fa-user"></i> My Profile</a>

                    <!-- <a class="nav-link" href="#"><i class="fa fa-user"></i> Notifications <span class="count">13</span></a> -->

                    <a class="nav-link" href="#"><i class="fa fa-cog"></i> Settings</a>
                    <?= Html::beginForm(['/site/logout'], 'post')
                        . Html::submitButton(
                        '<i class="fa fa-power-off"></i> Logout',
                        ['class' => 'nav-link normaliseBtn']
                        )
                        . Html::endForm()
                    ?> 
                 
                </div>
            </div>
           

            <!-- <div class="language-select dropdown" id="language-select">
                <a class="dropdown-toggle" href="#" data-toggle="dropdown"  id="language" aria-haspopup="true" aria-expanded="true">
                    <i class="flag-icon flag-icon-us"></i>
                </a>
                <div class="dropdown-menu" aria-labelledby="language">
                    <div class="dropdown-item">
                        <span class="flag-icon flag-icon-fr"></span>
                    </div>
                    <div class="dropdown-item">
                        <i class="flag-icon flag-icon-es"></i>
                    </div>
                    <div class="dropdown-item">
                        <i class="flag-icon flag-icon-us"></i>
                    </div>
                    <div class="dropdown-item">
                        <i class="flag-icon flag-icon-it"></i>
                    </div>
                </div>
            </div> -->

        </div>
    </div>

</header><!-- /header -->
<!-- Header-->

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">

                <h1><?=  isset($this->params['breadcrumbs'][0]) ? end($this->params['breadcrumbs']) : "Home" ?></h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
            <?= Breadcrumbs::widget([
                'itemTemplate' => "<li>{link}</li>\n",
                'homeLink' => [ 
                            'label' => Yii::t('yii', 'Home'),
                            'url' => Yii::$app->homeUrl."?r=",
                        ],
                'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
                ])  
            ?>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
<div class="header">

    

<!-- <li class="dropdown notifications-menu">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <i class="fa fa-bell-o"></i>
        <span class="label label-warning notifications-icon-count">0</span>
    </a>
    <ul class="dropdown-menu">
        <li class="header">You have <span class="notifications-header-count">0</span> notifications</li>
        <li>
            <ul class="menu">
                <div id="notifications"></div>
            </ul>
        </li>
        <li class="footer"><a href="#">View all</a> / <a href="#" id="notification-seen-all">Mark all as seen</a></li>
    </ul>
</li> -->
</div>
    <?= $content ?>
</div> <!-- .content -->
</div>
<!-- /#right-panel -->
</div>
</div>
   
    <!-- /#left-panel -->

 
</div>
<script>

$('body').toggleClass('open');
  $('#right-panel').toggleClass('fullwidth');
</script>
<?php } ?>
<?php $this->endBody() ?>
<?php $this->endPage() ?>
