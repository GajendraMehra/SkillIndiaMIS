<ul class="nav navbar-nav">
    <li class="active">
        <a href="<?= Yii::$app->homeUrl ?>"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
    </li>
    <h3 class="menu-title">Student Menu</h3><!-- /.menu-title -->

    <?php 
        // echo
        $className="menu-close";
        if (isset($_GET['r'])) {
        $className = ((
            preg_match('/scheme\b/', $_GET['r'])
            
        )) ? "hide" : "hide" ; 
        
        } 
    ?>
    <li class="menu-item-has-children dropdown  <?= $className; ?>">
        <a href="#" clases="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-laptop"></i>Schemes</a>
        <ul class="sub-menu children dropdown-menu <?= $className; ?>">
            <li><i class="fa fa-puzzle-piece"></i><a href="<?=  Yii::$app->homeUrl ?>?r=scheme">Manage Schemes</a></li>
            <!-- <li><i class="fa fa-file-word-o"></i><a href="ui-typgraphy.html">Typography</a></li> -->
        </ul>
    </li>


    <!-- <h3 class="menu-title">Icons</h3><!-- /.menu-title -->

    <!-- <li class="menu-item-has-children dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Icons</a>
        <ul class="sub-menu children dropdown-menu">
            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="font-fontawesome.html">Font Awesome</a></li>
            <li><i class="menu-icon ti-themify-logo"></i><a href="font-themify.html">Themefy Icons</a></li>
        </ul>
    </li> -->


</ul>