<?php use app\models\TpartnerDetail;
$tp_pending=TpartnerDetail::find()->where(['is_approved' => 2,'final_submit' => 1])->count();
?>
<ul class="nav navbar-nav">
    <li class="active">
        <a href="<?= Yii::$app->homeUrl ?>"> <i class="fa fa-bar-chart" aria-hidden="true"></i>&nbsp&nbspDashboard </a>
    </li>
    <h3 class="menu-title">Master Data</h3><!-- /.menu-title -->


    <!--  Sector-->
    <?php 
        // echo
        $className="menu-close";
        if (isset($_GET['r'])) {
        $className = ((
            preg_match('/sector\b/', $_GET['r'])
            
        )) ? "hide" : "hide" ; 
        
        } 
    ?>
    <li class="menu-item-has-children dropdown  <?= $className; ?>">
        <a href="#" clases="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-pie-chart"></i>Sectors</a>
        <ul class="sub-menu children dropdown-menu <?= $className; ?>">
            <li><i class="fa fa-plus-square"></i><a href="<?=  Yii::$app->homeUrl ?>?r=sector/create">Create Sector</a></li>
            <li><i class="fa fa-list-ul"></i><a href="<?=  Yii::$app->homeUrl ?>?r=sector/index">Manage Sector</a></li>
            <!-- <li><i class="fa fa-file-word-o"></i><a href="ui-typgraphy.html">Typography</a></li> -->
        </ul>
    </li>
    <?php 
        // echo
        $className="menu-close";
        if (isset($_GET['r'])) {
        $className = ((
            preg_match('/job\b/', $_GET['r'])
            
        )) ? "hide" : "hide" ; 
        
        } 
    ?>
    <li class="menu-item-has-children dropdown  <?= $className; ?>">
        <a href="#" clases="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-wrench"></i>Jobs</a>
        <ul class="sub-menu children dropdown-menu <?= $className; ?>">
            <li><i class="fa fa-plus-square"></i><a href="<?=  Yii::$app->homeUrl ?>?r=job/create">Create Job</a></li>
            <li><i class="fa fa-list-ul"></i><a href="<?=  Yii::$app->homeUrl ?>?r=job/index">Manage Job</a></li>
            <!-- <li><i class="fa fa-file-word-o"></i><a href="ui-typgraphy.html">Typography</a></li> -->
        </ul>
    </li>

    <!-- Scheme  -->
    <?php 
        // echo
        $className="menu-close";
        if (isset($_GET['r'])) {
        $className = ((
            preg_match('/scheme\b/', $_GET['r'])
            
        )) ? "hide" : "hide" ; 
        
        } 
    ?>
    <li class="menu-item-has-children dropdown  <?= $className; ?>">
        <a href="#" clases="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-laptop"></i>Schemes</a>
        <ul class="sub-menu children dropdown-menu <?= $className; ?>">
            <li><i class="fa fa-plus-square"></i><a href="<?=  Yii::$app->homeUrl ?>?r=scheme/create">Create Scheme</a></li>
            <li><i class="fa fa-list-ul"></i><a href="<?=  Yii::$app->homeUrl ?>?r=scheme">Manage Scheme</a></li>
            <!-- <li><i class="fa fa-file-word-o"></i><a href="ui-typgraphy.html">Typography</a></li> -->
        </ul>
    </li>
    

    <!-- Targets -->
    <?php 
        // echo
        $className="menu-close";
        if (isset($_GET['r'])) {
        $className = ((
            preg_match('/target\b/', $_GET['r'])
            
        )) ? "hide" : "hide" ; 
        
        } 
    ?>
    <li class="menu-item-has-children dropdown  <?= $className; ?>">
        <a href="#" clases="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bullseye"></i>Targets</a>
        <ul class="sub-menu children dropdown-menu <?= $className; ?>">
            <li><i class="fa fa-plus-square"></i><a href="<?=  Yii::$app->homeUrl ?>?r=target/create">Create Target</a></li>
            <li><i class="fa fa-list-ul"></i><a href="<?=  Yii::$app->homeUrl ?>?r=target/index">Manage Target</a></li>
            <!-- <li><i class="fa fa-file-word-o"></i><a href="ui-typgraphy.html">Typography</a></li> -->
        </ul>
    </li>

    <?php 
        // echo
        $className="menu-close";
        if (isset($_GET['r'])) {
        $className = ((
            preg_match('/tpartner\b/', $_GET['r'])
           
            
        )) ? "hide" : "hide" ; 
        
        } 
    ?>
    <li class="menu-item-has-children dropdown  <?= $className; ?>">
        <a href="#" clases="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-building menu-icon" aria-hidden="true"></i>Training Partners</a>
        <ul class="sub-menu children dropdown-menu <?= $className; ?>">
        <li><i class="fa fa-check-square" aria-hidden="true"></i><a href="<?=  Yii::$app->homeUrl ?>?r=tpartner&TpartnerDetail[is_approved]=1">Approved</a></li>
        <li><i class="fa fa-window-close" aria-hidden="true"></i><a href="<?=  Yii::$app->homeUrl ?>?r=tpartner&TpartnerDetail[is_approved]=0">Not Approved</a></li>
        <li><i class="fa fa-exclamation-triangle"></i><a href="<?=  Yii::$app->homeUrl ?>?r=tpartner&TpartnerDetail[is_approved]=2"> Pending <?= ($tp_pending>0) ? '<span class="badge badge-info">'.$tp_pending.'</span>' : '' ?></span></a></li>
            <!-- <li><i class="fa fa-file-word-o"></i><a href="ui-typgraphy.html">Typography</a></li> -->
        </ul>
    </li>


    <!-- <h3 class="menu-title">Icons</h3><!-- /.menu-title -->

    <!-- <li class="menu-item-has-children dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Icons</a>
        <ul class="sub-menu children dropdown-menu">
            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="font-fontawesome.html">Font Awesome</a></li>
            <li><i class="menu-icon ti-themify-logo"></i><a href="font-themify.html">Themefy Icons</a></li>
        </ul>
    </li> -->


</ul>