<?php 
use app\models\search\Targets as TargetsSearch;

use app\models\Targets;
use app\models\CommonModel;
 $tpdetails=CommonModel::getTpdetailbyuserid();
 $arcCount =Targets::find()->where(['tp_id'=>$tpdetails['id']])->count();


?>
<div class="row">
<!-- <h2>sd</h2> -->
<div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="stat-widget-one">
                    <div class="stat-icon dib"><i class="ti-money text-success border-success"></i></div>
                    <div class="stat-content dib">
                        <div class="stat-text">  
                        <a href="index.php?r=target/assigned-index"> Acheive Targets</a>
                             
                             </div>
                        <div class="stat-digit"></div>
                        <a href="index.php?r=target/assigned-index"><?= $arcCount ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>