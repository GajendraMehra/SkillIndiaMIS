<?php use aryelds\sweetalert\SweetAlert;
?>
<?php foreach(Yii::$app->session->getAllFlashes() as $type => $messages): ?>
<?php foreach($messages as $message): 
    switch ($type) {
        case 'login-success':
           
            ?>
              <script>
            // Display an error toast, with a title
               toastr.success("<?= $message ?>", 'Success')
               function myFunction() {
                // toastr.positionClass="toast-top-full-width";
                toastr.info("This application is under development . In case any suggestion or bug please write at support@demo.utmv.in .thank You. ", 'Before you use',{
                    timeOut: 5000
                })
                }
                setTimeout(myFunction, 5000);
                document.getElementById('alogin').click()
                 </script>
            <?php
               break;

               case 'success':
           
                ?>
                  <script>
               // Display an error toast, with a title
                   toastr.success("<?= $message ?>", 'Approved')
                
                </script>
                <?php
                   break;

          
               case 'register-error':
                $alertType = SweetAlert::TYPE_WARNING;
                echo SweetAlert::widget([
                    'options' => [
                        'title' =>$type,
                        'text' =>$message,
                        'type'=>  $alertType
                    ]
                    ]);
                        ?>

                        <script>
                                document.getElementById('aregister').click()
                        </script>
                        <?php
                break;
                case 'register-success':
                    $alertType = SweetAlert::TYPE_SUCCESS;
                    echo SweetAlert::widget([
                        'options' => [
                            'title' =>$type,
                            'text' =>$message,
                            'type'=>  $alertType
                        ]
                        ]);
                break;     
                 case 'login-error':
                    $alertType = SweetAlert::TYPE_ERROR;
                    echo SweetAlert::widget([
                        'options' => [
                            'title' =>$type,
                            'text' =>$message,
                            'type'=>  $alertType
                        ]
                        ]);
                        ?>
                        <script>
                                document.getElementById('alogin').click()
                        </script>
                        <?php
                break;  
                case 'login-error':
                    $alertType = SweetAlert::TYPE_ERROR;
                    echo SweetAlert::widget([
                        'options' => [
                            'title' =>$type,
                            'text' =>$message,
                            'type'=>  $alertType
                        ]
                        ]);
         
                break;
        default:
        echo SweetAlert::widget([
            'options' => [
                'title' =>$type,
                'text' =>$message
            ]
        ]);
         ?>
         
           <script>
           $( document ).ready(function() {
           
        // Display an error toast, with a title
        document.getElementById('alogin').click()
        });
          
       
    </script>
         <?php
            break;
    }
    
    ?>
  
    <!-- <div class="alert alert-<?= $type ?>" role="alert"><?= $message ?></div> -->
<?php endforeach ?>
<?php endforeach ?>