    <?php 
use app\models\TpartnerDetail;
use app\models\CommonModel;
?>
<ul class="nav navbar-nav">
    <li class="active">
        <a href="<?= Yii::$app->homeUrl ?>"> <i class="menu-icon fa fa-bar-chart"></i>Dashboard </a>
    </li>
    <h3 class="menu-title">Training Partner Menu</h3><!-- /.menu-title -->

    <?php 
        // echo
        $className="menu-close";
        if (isset($_GET['r'])) {
        $className = ((
            preg_match('/tpartner\/create\b/', $_GET['r'])
            // ||preg_match('/tpartner/create\b/', $_GET['r'])
            ||preg_match('/tpartner\b/', $_GET['r'])
        )) ? "show" : "hide" ; 
        
        } 
    ?>
    <li class="menu-item-has-children dropdown  <?= $className; ?>">
        <a href="#" clases="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-laptop"></i>Approval Request</a>
        <ul class="sub-menu children dropdown-menu <?= $className; ?>">
            <li><i class="fa fa-puzzle-piece"></i><a href="<?=  Yii::$app->homeUrl ?>?r=tpartner/create">Approval Status</a></li>
            <!-- <li><i class="fa fa-file-word-o"></i><a href="ui-typgraphy.html">Typography</a></li> -->
        </ul>
    </li>

    <?php 

 if(CommonModel::getTpdetailbyuserid()['is_approved']==1): 

      // target by admin
      $className="menu-close";
      if (isset($_GET['r'])) {
      $className = ((
        //   preg_match('/tar\/create\b/', $_GET['r'])
          // ||preg_match('/tpartner/create\b/', $_GET['r'])
          preg_match('/target\b/', $_GET['r'])
      )) ? "show" : "hide" ; 
      
      } 
  ?>
  <li class="menu-item-has-children dropdown  <?= $className; ?>">
      <a href="#" clases="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bullseye"></i>Achieved Targets</a>
      <ul class="sub-menu children dropdown-menu <?= $className; ?>">
          <!-- <li><i class="fa fa-plus-square"></i><a href="<?=  Yii::$app->homeUrl ?>?r=tcenter/create">All</a></li> -->
      <li><i class="fa fa-podcast"></i><a href="<?=  Yii::$app->homeUrl ?>?r=target/assigned-index">See All</a></li>
          <!-- <li><i class="fa fa-file-word-o"></i><a href="ui-typgraphy.html">Typography</a></li> -->
      </ul>
  </li>
  <?php
        // echo
        $className="menu-close";
        if (isset($_GET['r'])) {
        $className = ((
            preg_match('/tcenter\/create\b/', $_GET['r'])
            // ||preg_match('/tpartner/create\b/', $_GET['r'])
            ||preg_match('/tcenter\b/', $_GET['r'])
        )) ? "show" : "hide" ; 
        
        } 
    ?>
    <li class="menu-item-has-children dropdown  <?= $className; ?>">
        <a href="#" clases="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-university"></i>Training Centers</a>
        <ul class="sub-menu children dropdown-menu <?= $className; ?>">
            <li><i class="fa fa-plus-square"></i><a href="<?=  Yii::$app->homeUrl ?>?r=tcenter/create">Create New</a></li>
        <li><i class="fa fa-podcast"></i><a href="<?=  Yii::$app->homeUrl ?>?r=tcenter/index">All Centers</a></li>
            <!-- <li><i class="fa fa-file-word-o"></i><a href="ui-typgraphy.html">Typography</a></li> -->
        </ul>
    </li>

    <?php endif; ?>
    <!-- <h3 class="menu-title">Icons</h3><!-- /.menu-title -->

    <!-- <li class="menu-item-has-children dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Icons</a>
        <ul class="sub-menu children dropdown-menu">
            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="font-fontawesome.html">Font Awesome</a></li>
            <li><i class="menu-icon ti-themify-logo"></i><a href="font-themify.html">Themefy Icons</a></li>
        </ul>
    </li> -->


</ul>