<ul class="nav navbar-nav">
    <li class="active">
        <a href="<?= Yii::$app->homeUrl ?>"> <i class="fa fa-bar-chart"></i>Dashboard </a>
    </li>
    <h3 class="menu-title">Training Center Menu</h3><!-- /.menu-title -->

   


    <!-- <h3 class="menu-title">Icons</h3><!-- /.menu-title -->

    <!-- <li class="menu-item-has-children dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Icons</a>
        <ul class="sub-menu children dropdown-menu">
            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="font-fontawesome.html">Font Awesome</a></li>
            <li><i class="menu-icon ti-themify-logo"></i><a href="font-themify.html">Themefy Icons</a></li>
        </ul>
    </li> -->


</ul>